export const tinyBasePreferencesSchema = {
  "currentJournalDirectory": {
    "type": "string"
  },
  "selectedCurrency": {
    "type": "string"
  }
} as const;
