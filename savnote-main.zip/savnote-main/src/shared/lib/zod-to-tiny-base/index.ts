export { zObjectToTinyTable } from "./zObjectToTinyTable";
